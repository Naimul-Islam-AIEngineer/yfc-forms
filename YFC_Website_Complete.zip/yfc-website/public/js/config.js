// ============================================================
// YFC CONFIG — Replace with your actual Supabase credentials
// After following the setup guide on the website
// ============================================================
const YFC_CONFIG = {
  supabaseUrl: localStorage.getItem('yfc_supabase_url') || '',
  supabaseKey: localStorage.getItem('yfc_supabase_key') || '',
  adminPassword: localStorage.getItem('yfc_admin_pass') || 'yfc2024admin',
};

// ============================================================
// SUPABASE CLIENT (lightweight fetch wrapper — no SDK needed)
// ============================================================
const DB = {
  async insert(table, data) {
    const url = YFC_CONFIG.supabaseUrl;
    const key = YFC_CONFIG.supabaseKey;
    if (!url || !key) {
      // Fallback: save to localStorage for demo
      const stored = JSON.parse(localStorage.getItem('yfc_' + table) || '[]');
      stored.unshift({ ...data, id: Date.now(), created_at: new Date().toISOString() });
      localStorage.setItem('yfc_' + table, JSON.stringify(stored));
      return { ok: true, local: true };
    }
    try {
      const res = await fetch(`${url}/rest/v1/${table}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': key,
          'Authorization': `Bearer ${key}`,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(data)
      });
      return { ok: res.ok, status: res.status };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  },

  async getAll(table) {
    const url = YFC_CONFIG.supabaseUrl;
    const key = YFC_CONFIG.supabaseKey;
    if (!url || !key) {
      return JSON.parse(localStorage.getItem('yfc_' + table) || '[]');
    }
    try {
      const res = await fetch(`${url}/rest/v1/${table}?order=created_at.desc`, {
        headers: {
          'apikey': key,
          'Authorization': `Bearer ${key}`
        }
      });
      if (res.ok) return await res.json();
      return [];
    } catch (e) {
      return JSON.parse(localStorage.getItem('yfc_' + table) || '[]');
    }
  }
};

// ============================================================
// HELPERS
// ============================================================
function showToast(msg, type = '') {
  const t = document.getElementById('globalToast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(() => t.className = 'toast', 3000);
}

function showLoading(show) {
  document.getElementById('loadingOverlay').className = 'loading-overlay' + (show ? ' show' : '');
}

function navigate(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  const page = document.getElementById(pageId);
  if (page) {
    page.classList.add('active');
    window.scrollTo(0, 0);
  }
  const link = document.querySelector(`.nav-links a[data-page="${pageId}"]`);
  if (link) link.classList.add('active');
}

function getChecked(name) {
  return Array.from(document.querySelectorAll(`input[name="${name}"]:checked`)).map(el => el.value).join(', ');
}

function getActive(groupId) {
  return Array.from(document.querySelectorAll(`#${groupId} .pill.active`)).map(p => p.textContent.trim()).join(', ');
}

function val(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}

function exportCSV(data, filename) {
  if (!data.length) { showToast('No data to export', 'error'); return; }
  const keys = Object.keys(data[0]);
  const csv = [keys.join(','), ...data.map(row =>
    keys.map(k => `"${String(row[k] || '').replace(/"/g, '""')}"`).join(',')
  )].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}
