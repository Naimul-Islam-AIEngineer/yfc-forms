// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  navigate('home');
  // Set today's date for date fields
  const today = new Date().toISOString().split('T')[0];
  ['lg-date', 'sv-date'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = today;
  });
  // Load config values into setup fields
  document.getElementById('cfg-url').value = localStorage.getItem('yfc_supabase_url') || '';
  document.getElementById('cfg-key').value = localStorage.getItem('yfc_supabase_key') || '';
});

// ============================================================
// NAVIGATION
// ============================================================
// Already defined in config.js but adding event delegation for nav links
document.querySelectorAll('.nav-links a[data-page]').forEach(a => {
  a.addEventListener('click', function(e) {
    e.preventDefault();
    navigate(this.dataset.page);
  });
});

// ============================================================
// UI HELPERS
// ============================================================
let starValue = 0;

function selectBlood(el, hiddenId) {
  el.closest('.blood-grid').querySelectorAll('.blood-btn').forEach(b => b.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById(hiddenId).value = el.textContent.trim();
}

function toggleYN(prefix, choice) {
  document.getElementById(prefix + '-yes').classList.remove('yes');
  document.getElementById(prefix + '-no').classList.remove('no');
  if (choice === 'yes') document.getElementById(prefix + '-yes').classList.add('yes');
  else document.getElementById(prefix + '-no').classList.add('no');
  document.getElementById(prefix).value = choice;
}

function setStar(n) {
  starValue = n;
  document.getElementById('lg-stars-val').value = n;
  document.querySelectorAll('#lg-stars .star').forEach((s, i) => {
    s.classList.toggle('lit', i < n);
  });
}

function selectLgStatus(s) {
  document.getElementById('lg-status').value = s;
  ['pending','inprogress','done','blocked'].forEach(k => {
    document.getElementById('lgst-' + k).classList.remove('sel');
  });
  document.getElementById('lgst-' + s).classList.add('sel');
}

function getActivePills(groupId) {
  return Array.from(document.querySelectorAll('#' + groupId + ' .pill.active'))
    .map(p => p.textContent.trim()).join(', ');
}

function getOnDays() {
  return Array.from(document.querySelectorAll('.day-btn.on'))
    .map(d => d.textContent.trim()).join(', ');
}

function clearForm(type) {
  const inputs = document.querySelectorAll(`#page-${type} input:not([readonly]), #page-${type} textarea, #page-${type} select`);
  inputs.forEach(el => {
    if (el.type === 'checkbox') el.checked = false;
    else if (el.type === 'range') { el.value = 5; }
    else el.value = '';
  });
  document.querySelectorAll(`#page-${type} .blood-btn.selected`).forEach(b => b.classList.remove('selected'));
  document.querySelectorAll(`#page-${type} .pill.active`).forEach(p => p.classList.remove('active'));
  document.querySelectorAll(`#page-${type} .day-btn.on`).forEach(d => d.classList.remove('on'));
  document.querySelectorAll(`#page-${type} .yn-btn`).forEach(b => b.classList.remove('yes','no'));
  document.querySelectorAll(`#page-${type} .status-badge`).forEach(b => b.classList.remove('sel'));
  document.querySelectorAll(`#page-${type} .star.lit`).forEach(s => s.classList.remove('lit'));
  document.querySelectorAll(`#page-${type} .check-item`).forEach(c => c.classList.remove('checked'));
  // Reset range display values
  if (type === 'blood') { document.getElementById('bd-range-out').textContent = '10km'; }
  if (type === 'learning') {
    document.getElementById('lg-value-out').textContent = '5';
    document.getElementById('lg-urgency-out').textContent = '5';
    starValue = 0;
  }
}

function showSuccess(formId) {
  const banner = document.getElementById('success-' + formId);
  if (banner) {
    banner.classList.add('show');
    banner.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => banner.classList.remove('show'), 6000);
  }
}

// ============================================================
// SUBMIT: MEMBERSHIP
// ============================================================
async function submitMembership() {
  const name = val('m-name'), phone = val('m-phone1'), emgName = val('m-emg-name'), emgPhone = val('m-emg-phone');
  const gender = val('m-gender');
  if (!name || !phone || !emgName || !emgPhone || !gender) {
    showToast('Please fill in all required fields', 'error'); return;
  }
  if (!document.getElementById('m-declare').checked) {
    showToast('Please check the declaration checkbox', 'error'); return;
  }
  showLoading(true);
  const data = {
    name, dob: val('m-dob'), age: val('m-age'), nid: val('m-nid'),
    gender, blood_group: val('m-blood'),
    phone1: phone, phone2: val('m-phone2'), whatsapp: val('m-whatsapp'),
    email: val('m-email'), address: val('m-addr'), postal_code: val('m-postal'),
    thana: val('m-thana'), district: val('m-district'), division: val('m-division'),
    perm_address: val('m-perm-addr'),
    education: val('m-edu'), institution: val('m-institution'),
    class_year: val('m-class'), profession: val('m-profession'),
    interests: getChecked('m_interest'),
    emg_name: emgName, emg_relation: val('m-emg-relation'), emg_phone: emgPhone,
    motivation: val('m-motivation'),
    terms_agreed: 'Yes',
    declaration: 'Agreed'
  };
  const result = await DB.insert('memberships', data);
  showLoading(false);
  if (result.ok) {
    clearForm('membership');
    showSuccess('membership');
    showToast('Membership application submitted!', 'success');
  } else {
    showToast('Error submitting. Check console.', 'error');
  }
}

// ============================================================
// SUBMIT: BLOOD DONOR
// ============================================================
async function submitBlood() {
  const name = val('bd-name'), phone = val('bd-phone'), bloodGroup = val('bd-blood');
  const willing = val('bd-willing'), district = val('bd-district'), classProf = val('bd-class');
  if (!name || !phone || !district || !classProf) {
    showToast('Please fill in all required fields', 'error'); return;
  }
  if (!bloodGroup) { showToast('Please select a blood group', 'error'); return; }
  if (!document.getElementById('bd-consent').checked) {
    showToast('Please check the consent checkbox', 'error'); return;
  }
  showLoading(true);
  const data = {
    name, dob: val('bd-dob'), age: val('bd-age'), nid: val('bd-nid'),
    gender: val('bd-gender'), blood_group: bloodGroup,
    phone, email: val('bd-email'), address: val('bd-addr'),
    district, division: val('bd-division'),
    education: val('bd-edu'), class_profession: classProf,
    major_health: val('bd-major-health'), minor_health: val('bd-minor-health'),
    medications: val('bd-medications'),
    last_donation: val('bd-last-donation'), donation_count: val('bd-donation-count'),
    willing: willing || 'not specified',
    travel_range: val('bd-range-val') + ' km',
    available_days: getOnDays(),
    time_slots: getActivePills('bd-time-group')
  };
  const result = await DB.insert('blood_donors', data);
  showLoading(false);
  if (result.ok) {
    clearForm('blood');
    document.getElementById('success-blood').innerHTML = '<h3>✅ Registered as Blood Donor!</h3><p>Thank you for registering. You may be contacted when blood is urgently needed.</p>';
    showSuccess('blood');
    showToast('Blood donor registered!', 'success');
  } else {
    showToast('Error submitting. Check console.', 'error');
  }
}

// ============================================================
// SUBMIT: INITIATIVE
// ============================================================
async function submitInitiative() {
  const title = val('ini-title'), category = val('ini-category');
  const area = val('ini-area'), proposerName = val('ini-proposer-name'), proposerPhone = val('ini-proposer-phone');
  const location = val('ini-location'), beneficiaries = val('ini-beneficiaries');
  if (!title || !category || !area || !proposerName || !proposerPhone || !location || !beneficiaries) {
    showToast('Please fill in all required fields', 'error'); return;
  }
  if (!document.getElementById('ini-declare').checked) {
    showToast('Please accept the No-Politics Declaration', 'error'); return;
  }
  showLoading(true);
  const data = {
    reg_number: val('ini-reg'), founded: val('ini-founded'),
    phone: val('ini-phone'), email: val('ini-email'), area,
    title, category, start_date: val('ini-start'), end_date: val('ini-end'),
    location, budget: val('ini-budget'), beneficiaries,
    outcome: val('ini-outcome'),
    proposer_name: proposerName, proposer_role: val('ini-proposer-role'),
    proposer_phone: proposerPhone,
    declaration_agreed: 'Yes'
  };
  const result = await DB.insert('initiatives', data);
  showLoading(false);
  if (result.ok) {
    clearForm('initiative');
    document.getElementById('success-initiative').innerHTML = '<h3>✅ Initiative Submitted!</h3><p>Your initiative has been recorded. The committee will review and respond.</p>';
    showSuccess('initiative');
    showToast('Initiative submitted!', 'success');
  } else {
    showToast('Error submitting.', 'error');
  }
}

// ============================================================
// SUBMIT: SOVA FORM
// ============================================================
async function submitSova() {
  const name = val('sv-name'), phone = val('sv-phone');
  if (!name || !phone) {
    showToast('Name and phone are required', 'error'); return;
  }
  showLoading(true);
  const data = {
    name, membership_id: val('sv-mid'), sova_num: val('sv-sova-num'),
    phone, class_profession: val('sv-class'), date: val('sv-date'),
    roles: getChecked('sv_role'), skill: val('sv-skill'),
    sectors: getChecked('sv_sector'),
    proposals: val('sv-proposals'), discussion: val('sv-discussion'),
    problem: val('sv-problem'), vision: val('sv-vision'),
    suggestion: val('sv-suggestion')
  };
  const result = await DB.insert('sova_forms', data);
  showLoading(false);
  if (result.ok) {
    clearForm('sova');
    document.getElementById('success-sova').innerHTML = '<h3>✅ Sova Form Submitted!</h3><p>Your ideas and proposals have been recorded. Thank you for contributing!</p>';
    showSuccess('sova');
    showToast('Sova form submitted!', 'success');
  } else {
    showToast('Error submitting.', 'error');
  }
}

// ============================================================
// SUBMIT: LEARNING LOG
// ============================================================
async function submitLearning() {
  const name = val('lg-name'), task = val('lg-task'), date = val('lg-date');
  if (!name || !task || !date) {
    showToast('Name, task and date are required', 'error'); return;
  }
  showLoading(true);
  const data = {
    name, date, task,
    category: getActivePills('lg-cat'),
    role: getActivePills('lg-role'),
    learning: val('lg-learning'),
    value_score: val('lg-value'),
    urgency_score: val('lg-urgency'),
    stars: val('lg-stars-val'),
    went_well: val('lg-went-well'),
    improve: val('lg-improve'),
    emotion: getActivePills('lg-emotion'),
    next_action: val('lg-next'),
    deadline: val('lg-deadline'),
    responsible: val('lg-responsible'),
    status: val('lg-status'),
    comment: val('lg-comment'),
    skill: val('lg-skill'),
    one_liner: val('lg-oneliner')
  };
  const result = await DB.insert('learning_logs', data);
  showLoading(false);
  if (result.ok) {
    clearForm('learning');
    document.getElementById('success-learning').innerHTML = '<h3>✅ Learning Entry Saved!</h3><p>Your reflection has been recorded. Keep learning, keep growing!</p>';
    showSuccess('learning');
    showToast('Learning log saved!', 'success');
  } else {
    showToast('Error submitting.', 'error');
  }
}

// ============================================================
// ADMIN
// ============================================================
let adminUnlocked = false;
let adminData = {};

function openAdmin() {
  navigate('page-admin');
  if (!adminUnlocked) {
    document.getElementById('admin-lock-screen').style.display = 'block';
    document.getElementById('admin-panel').style.display = 'none';
  }
}

function unlockAdmin() {
  const pass = document.getElementById('admin-pass-input').value;
  const correct = localStorage.getItem('yfc_admin_pass') || 'yfc2024admin';
  if (pass === correct) {
    adminUnlocked = true;
    document.getElementById('admin-lock-screen').style.display = 'none';
    document.getElementById('admin-panel').style.display = 'block';
    loadAdminData();
  } else {
    showToast('Incorrect password', 'error');
  }
}

// Allow Enter key for admin login
document.getElementById('admin-pass-input')?.addEventListener('keydown', e => {
  if (e.key === 'Enter') unlockAdmin();
});

async function loadAdminData() {
  showLoading(true);
  const tables = ['memberships', 'blood_donors', 'initiatives', 'sova_forms', 'learning_logs'];
  for (const t of tables) {
    adminData[t] = await DB.getAll(t);
  }
  showLoading(false);
  renderAdminStats();
  renderTable('memberships');
}

function renderAdminStats() {
  const stats = [
    { label: 'Total Members', val: (adminData.memberships || []).length, color: 'var(--navy)' },
    { label: 'Blood Donors', val: (adminData.blood_donors || []).length, color: 'var(--red)' },
    { label: 'Initiatives', val: (adminData.initiatives || []).length, color: 'var(--green)' },
    { label: 'Sova Forms', val: (adminData.sova_forms || []).length, color: 'var(--gold)' },
    { label: 'Learning Logs', val: (adminData.learning_logs || []).length, color: '#6B3FA0' },
  ];
  document.getElementById('admin-stats').innerHTML = stats.map(s =>
    `<div class="stat-card"><div class="stat-num" style="color:${s.color}">${s.val}</div><div class="stat-lbl">${s.label}</div></div>`
  ).join('');
}

const tableColumns = {
  memberships: ['created_at','name','phone1','blood_group','district','email','education','interests'],
  blood_donors: ['created_at','name','blood_group','phone','district','age','willing','travel_range','major_health'],
  initiatives: ['created_at','title','category','proposer_name','location','budget','start_date'],
  sova_forms: ['created_at','name','phone','sova_num','roles','sectors','proposals'],
  learning_logs: ['created_at','name','task','value_score','urgency_score','stars','next_action','status'],
};

function renderTable(tableName) {
  const data = adminData[tableName] || [];
  const cols = tableColumns[tableName];
  const tbody = document.querySelector(`#tbl-${tableName} tbody`);
  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="${cols.length}" class="empty-table">No submissions yet</td></tr>`;
    return;
  }
  tbody.innerHTML = data.map(row =>
    `<tr>${cols.map(c => {
      let v = row[c] || '';
      if (c === 'created_at' && v) v = v.slice(0,10);
      return `<td title="${v}">${v}</td>`;
    }).join('')}</tr>`
  ).join('');
}

function switchAdminTab(name) {
  document.querySelectorAll('.admin-tab').forEach((t,i) => t.classList.remove('active'));
  document.querySelectorAll('.admin-tab-content').forEach(c => c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('tab-' + name).classList.add('active');
  if (name !== 'setup' && adminData[name]) renderTable(name);
}

function exportTable(tableName) {
  const data = adminData[tableName] || [];
  exportCSV(data, `YFC_${tableName}_${new Date().toISOString().slice(0,10)}.csv`);
}

// ============================================================
// CONFIG SAVE
// ============================================================
function saveConfig() {
  const url = document.getElementById('cfg-url').value.trim();
  const key = document.getElementById('cfg-key').value.trim();
  const pass = document.getElementById('cfg-pass').value.trim();
  if (url) localStorage.setItem('yfc_supabase_url', url);
  if (key) localStorage.setItem('yfc_supabase_key', key);
  if (pass) localStorage.setItem('yfc_admin_pass', pass);
  YFC_CONFIG.supabaseUrl = url;
  YFC_CONFIG.supabaseKey = key;
  if (pass) YFC_CONFIG.adminPassword = pass;
  showToast('Configuration saved!', 'success');
}

// ============================================================
// CHECKBOX VISUAL UPDATE
// ============================================================
document.addEventListener('change', function(e) {
  if (e.target.type === 'checkbox') {
    const item = e.target.closest('.check-item, .term-item');
    if (item) item.classList.toggle('checked', e.target.checked);
  }
});
