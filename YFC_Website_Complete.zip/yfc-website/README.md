# Youth For Change — Forms Portal

A complete multi-form web portal for Youth for Change with centralized data storage.

## Forms Included
1. **Membership Registration Form** (with Terms & Conditions)
2. **Blood Donor Registration Form**
3. **Initiative & Declaration Form**
4. **Sova / Meeting Participation Form**
5. **Daily Learning Log**

## Deploy on Vercel (Free — Recommended)

1. Upload this entire folder to GitHub as a new repository
2. Go to [vercel.com](https://vercel.com) → Sign up with GitHub
3. Click **Add New Project** → Import your GitHub repo
4. Click **Deploy** — done! You get a free URL like `yfc-forms.vercel.app`

## Deploy on GitHub Pages (Also Free)

1. Upload to GitHub repo
2. Go to repo Settings → Pages
3. Set Source: **Deploy from branch** → `main` → `/public`
4. Your site will be at `https://yourusername.github.io/reponame`

## Setting Up the Database (Supabase — Free)

To store form responses permanently (accessible from anywhere):

1. Go to [supabase.com](https://supabase.com) → Create free account
2. Create a new project
3. Go to **SQL Editor** and paste the SQL from the website's Admin → Setup tab
4. Go to **Settings → API** and copy:
   - **Project URL** (looks like `https://xxxx.supabase.co`)
   - **anon public key** (long string starting with `eyJ...`)
5. On your website, go to **Admin** → enter password → **Setup tab**
6. Paste your Supabase URL and anon key → Save

## Admin Access

- Default password: `yfc2024admin`
- Change it in Admin → Setup
- View all form submissions, filter by form type, export to CSV

## Without Supabase

The website works without Supabase — data saves to the browser's localStorage. 
This is fine for testing but data is lost if the browser clears storage.
For permanent storage, set up Supabase (takes 5 minutes).

## Files

```
yfc-website/
├── public/
│   ├── index.html          # Main website (all forms)
│   ├── css/
│   │   └── style.css       # All styles
│   └── js/
│       ├── config.js       # Database config & helpers
│       └── app.js          # Form logic & admin
└── vercel.json             # Vercel deployment config
```
